package com.vamps.music

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Locale

private val Bg = Color(0xFF090A0D)
private val Surface1 = Color(0xFF14171D)
private val Surface2 = Color(0xFF1D222B)
private val Txt = Color(0xFFF3F4F6)
private val Sub = Color(0xFFA1A6B0)
private val Dim = Color(0xFF747B87)
private val Accent = Color(0xFFC6CAD2)
private val Stroke = Color.White.copy(alpha = .09f)

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 10, 13)
        window.navigationBarColor = android.graphics.Color.rgb(9, 10, 13)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({ runCatching { controller = f.get() } }, mainExecutor)
        setContent { VampsTheme { VampsApp({ controller }, { tracks, selected ->
            controller?.let { c ->
                val media = tracks.map { t -> MediaItem.Builder().setUri(t.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album).build()).build() }
                val index = tracks.indexOfFirst { it.uri == selected.uri }.coerceAtLeast(0)
                c.setMediaItems(media, index, 0L); c.prepare(); c.play()
            }
        }) } }
    }
    override fun onDestroy() { future?.let { MediaController.releaseFuture(it) }; future = null; controller = null; super.onDestroy() }
}

private data class Track(val id: Long, val uri: Uri, val title: String, val artist: String, val album: String, val duration: Long)
private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Home), SEARCH("Search", Icons.Rounded.Search), LIBRARY("Library", Icons.Rounded.LibraryMusic), CONNECT("Connect", Icons.Rounded.Hub), PROFILE("Profile", Icons.Rounded.Person)
}

@Composable private fun VampsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, onPrimary = Bg, background = Bg, onBackground = Txt, surface = Surface1, onSurface = Txt, secondary = Sub, outline = Stroke), content = content)
}

@Composable private fun VampsApp(controller: () -> MediaController?, play: (List<Track>, Track) -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(Tab.HOME) }
    var library by remember { mutableStateOf(emptyList<Track>()) }
    var search by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("Choose something to play") }
    var artist by remember { mutableStateOf("Your music starts here") }
    var isPlaying by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var playerOpen by remember { mutableStateOf(false) }
    var queueOpen by remember { mutableStateOf(false) }
    var sleepOpen by remember { mutableStateOf(false) }
    var sleep by remember { mutableIntStateOf(0) }
    var infoMessage by remember { mutableStateOf<String?>(null) }
    var liked by remember { mutableStateOf(setOf<Long>()) }
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    fun scan() { library = loadAudio(ctx) }
    val request = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) scan() }
    fun requestScan() { if (ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED) scan() else request.launch(permission) }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED) scan()
        while (isActive) {
            controller()?.let { c ->
                pos = c.currentPosition.coerceAtLeast(0L); dur = c.duration.takeIf { it > 0 } ?: 0L; isPlaying = c.isPlaying
                c.currentMediaItem?.mediaMetadata?.let { m -> title = m.title?.toString() ?: title; artist = m.artist?.toString() ?: artist }
            }
            delay(350)
        }
    }
    LaunchedEffect(sleep) { if (sleep > 0) { delay(sleep * 60_000L); controller()?.pause(); sleep = 0 } }
    val results = remember(library, search) { if (search.isBlank()) library else library.filter { it.title.contains(search, true) || it.artist.contains(search, true) || it.album.contains(search, true) } }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            TopBar(tab)
            AnimatedContent(tab, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "vamps-page") { page ->
                when (page) {
                    Tab.HOME -> HomePage(library, requestScan) { play(library, it); playerOpen = true }
                    Tab.SEARCH -> SearchPage(search, { search = it }, results) { play(results, it); playerOpen = true }
                    Tab.LIBRARY -> LibraryPage(library, liked, requestScan, { play(library, it); playerOpen = true }) { t -> liked = if (t.id in liked) liked - t.id else liked + t.id }
                    Tab.CONNECT -> ConnectPage()
                    Tab.PROFILE -> ProfilePage(sleep > 0, { sleepOpen = true }) { infoMessage = it }
                }
            }
            Spacer(Modifier.weight(1f, fill = false))
            if (controller()?.currentMediaItem != null || title != "Choose something to play") {
                MiniPlayer(title, artist, isPlaying, pos, dur, { playerOpen = true }, { controller()?.let { if (it.isPlaying) it.pause() else it.play() } }, { controller()?.seekToNextMediaItem() })
            }
            FloatingNav(tab) { tab = it }
        }
        if (playerOpen) PlayerPage(title, artist, isPlaying, pos, dur, { playerOpen = false }, { controller()?.let { if (it.isPlaying) it.pause() else it.play() } }, { controller()?.seekToPreviousMediaItem() }, { controller()?.seekToNextMediaItem() }, { if (dur > 0) controller()?.seekTo((dur * it).toLong()) }, { queueOpen = true }, { sleepOpen = true }) { infoMessage = "Lyrics are not connected in this build. A licensed lyrics provider and source-specific permissions are required before displaying lyrics." }
        if (sleepOpen) SleepDialog(sleep, { sleepOpen = false }) { sleep = it; sleepOpen = false }
        if (queueOpen) QueueDialog(controller(), { queueOpen = false })
        infoMessage?.let { message -> AlertDialog(onDismissRequest = { infoMessage = null }, title = { Text("Feature availability", color = Txt) }, text = { Text(message, color = Sub) }, confirmButton = { TextButton(onClick = { infoMessage = null }) { Text("Got it", color = Accent) } }, containerColor = Surface1) }
    }
}

private fun loadAudio(context: Context): List<Track> {
    val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val cols = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION)
    val out = mutableListOf<Track>()
    runCatching {
        context.contentResolver.query(uri, cols, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val ti = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val ar = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val al = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM); val du = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) { val n = c.getLong(id); out += Track(n, Uri.withAppendedPath(uri, n.toString()), c.getString(ti) ?: "Unknown track", c.getString(ar)?.takeUnless { it == "<unknown>" } ?: "Unknown artist", c.getString(al)?.takeUnless { it == "<unknown>" } ?: "Unknown album", c.getLong(du)) }
        }
    }
    return out
}

@Composable private fun TopBar(tab: Tab) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 21.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFF424954), Color(0xFF171A20)))), contentAlignment = Alignment.Center) { Text("V", color = Txt, fontSize = 23.sp, fontWeight = FontWeight.Black) }
            Column { Text("VAMPS", color = Txt, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.5.sp); Text("M U S I C", color = Dim, fontSize = 8.sp, letterSpacing = 2.sp) }
        }
        Text(tab.label.uppercase(), color = Dim, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable private fun HomePage(tracks: List<Track>, onScan: () -> Unit, onPlay: (Track) -> Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 21.dp).padding(bottom = 12.dp)) {
        Spacer(Modifier.height(13.dp)); Text("YOUR SOUND,\nWITHOUT LIMITS.", color = Txt, fontSize = 31.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.7).sp)
        Text("A quieter place for everything you listen to.", color = Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 9.dp))
        Spacer(Modifier.height(24.dp))
        GlassCard {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("YOUR LIBRARY", color = Accent, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Icon(Icons.Rounded.GraphicEq, null, tint = Sub) }
                Spacer(Modifier.height(25.dp)); Text(if (tracks.isEmpty()) "Start with what you own." else "${tracks.size} tracks, ready when you are.", color = Txt, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                Text("Your device library, organized in one place.", color = Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)); Spacer(Modifier.height(17.dp))
                Button(onClick = onScan, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)) { Icon(Icons.Rounded.FolderOpen, null); Spacer(Modifier.width(7.dp)); Text("Scan device library") }
            }
        }
        Spacer(Modifier.height(25.dp)); Heading("RECENTLY ADDED", "${tracks.size} tracks")
        if (tracks.isEmpty()) EmptyCard("Your music will appear here", "Scan your device library to get started.", Icons.Rounded.MusicNote)
        else tracks.take(5).forEachIndexed { i, t -> TrackRow(t, i + 1) { onPlay(t) } }
        Spacer(Modifier.height(22.dp)); Heading("YOUR SPACE", "VAMPS")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { FeatureCard("Playlists", "Your collections", Icons.Rounded.QueueMusic, Modifier.weight(1f)); FeatureCard("Listening", "Recently played", Icons.Rounded.History, Modifier.weight(1f)) }
    }
}

@Composable private fun SearchPage(query: String, onQuery: (String) -> Unit, tracks: List<Track>, onPlay: (Track) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 21.dp)) {
        Text("Find your next repeat.", color = Txt, fontSize = 24.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(15.dp))
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth(), placeholder = { Text("Search your local library", color = Dim) }, leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Sub) }, singleLine = true, shape = RoundedCornerShape(17.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Stroke, focusedTextColor = Txt, unfocusedTextColor = Txt))
        Spacer(Modifier.height(15.dp)); Text("LOCAL RESULTS", color = Dim, fontSize = 10.sp, letterSpacing = 1.7.sp)
        if (tracks.isEmpty()) EmptyCard("No matches", "Try another title, artist or album.", Icons.Rounded.Search)
        else LazyColumn(contentPadding = PaddingValues(bottom = 10.dp)) { items(tracks, key = { it.id }) { TrackRow(it, null) { onPlay(it) } } }
    }
}

@Composable private fun LibraryPage(tracks: List<Track>, liked: Set<Long>, onScan: () -> Unit, onPlay: (Track) -> Unit, onLike: (Track) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 21.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Your library", color = Txt, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("${tracks.size} tracks on this device", color = Sub, fontSize = 12.sp) }; OutlinedButton(onClick = onScan, shape = RoundedCornerShape(13.dp), border = BorderStroke(1.dp, Stroke)) { Icon(Icons.Rounded.Refresh, null); Text("Rescan") } }
        Spacer(Modifier.height(14.dp))
        if (tracks.isEmpty()) EmptyCard("Your library is waiting", "Allow audio access and scan your device.", Icons.Rounded.LibraryMusic)
        else LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) { items(tracks, key = { it.id }) { t -> Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { TrackRow(t, null) { onPlay(t) } }; IconButton(onClick = { onLike(t) }) { Icon(if (t.id in liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Like", tint = if (t.id in liked) Accent else Dim) } } } }
    }
}

@Composable private fun ConnectPage() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 21.dp)) {
        Text("Your services.", color = Txt, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Provider-owned sign-in and permissions. No passwords stored in VAMPS.", color = Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
        ProviderCard("Spotify", "Official authorization and supported remote playback.", "Developer app + SDK configuration required", "com.spotify.music")
        ProviderCard("YouTube", "Official player and supported content discovery.", "Google developer configuration required", "com.google.android.youtube")
        ProviderCard("YouTube Music", "Supported app handoff; no public unrestricted music API.", "App handoff only", "com.google.android.apps.youtube.music")
        ProviderCard("SoundCloud", "OAuth 2.1 / PKCE and API-permitted playback.", "Developer application required", "com.soundcloud.android")
        GlassCard { Text("Provider login is not activated in this build. Each integration needs its own registered developer application, client configuration and approved scopes. These cards open the official apps; they do not claim your account is connected.", color = Sub, fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.padding(15.dp)) }
    }
}

@Composable private fun ProviderCard(name: String, description: String, status: String, pkg: String) {
    val ctx = LocalContext.current
    Surface(color = Surface1, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Stroke), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Surface2), contentAlignment = Alignment.Center) { Text(name.take(1), color = Txt, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            Column(Modifier.weight(1f).padding(horizontal = 11.dp)) { Text(name, color = Txt, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); Text(description, color = Sub, fontSize = 10.sp, lineHeight = 14.sp); Text(status, color = Dim, fontSize = 9.sp, modifier = Modifier.padding(top = 4.dp)) }
            TextButton(onClick = { val intent = ctx.packageManager.getLaunchIntentForPackage(pkg); if (intent != null) ctx.startActivity(intent) else ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${name.replace(" ", "+")}+official+app"))) }) { Text("Open app", color = Accent, fontSize = 10.sp) }
        }
    }
}

@Composable private fun ProfilePage(sleepActive: Boolean, onSleep: () -> Unit, onInfo: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 21.dp)) {
        Text("Your experience", color = Txt, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Playback tools and app preferences.", color = Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
        SettingRow("Sleep timer", if (sleepActive) "Timer active" else "Stop playback automatically", Icons.Rounded.Timer, onSleep)
        SettingRow("Equalizer", "Not active yet — device effects vary", Icons.Rounded.Tune) { onInfo("Equalizer controls are not implemented in this build. A native audio effect can only be attached to VAMPS-managed playback sessions, and support varies by device.") }
        SettingRow("Crossfade", "Not active yet", Icons.Rounded.CompareArrows) { onInfo("Crossfade is not implemented yet. It requires a two-player transition engine and is limited to sources VAMPS is permitted to control.") }
        SettingRow("Gapless playback", "Depends on decoder and files", Icons.Rounded.SkipNext) { onInfo("Gapless playback depends on the audio decoder and source files. This build uses Media3 defaults and does not expose a separate gapless setting.") }
        SettingRow("Audio output", "Android output routing", Icons.Rounded.Speaker) { onInfo("Output selection currently uses Android system routing. A dedicated cast integration is not included in this build.") }
        Spacer(Modifier.height(20.dp)); Text("VAMPS MUSIC", color = Dim, fontSize = 10.sp, letterSpacing = 2.sp); Text("Version 1.0 • Obsidian", color = Sub, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable private fun PlayerPage(title: String, artist: String, playing: Boolean, pos: Long, dur: Long, close: () -> Unit, toggle: () -> Unit, previous: () -> Unit, next: () -> Unit, seek: (Float) -> Unit, queue: () -> Unit, sleep: () -> Unit, lyrics: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg.copy(.985f))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 25.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = close) { Icon(Icons.Rounded.KeyboardArrowDown, "Close", tint = Txt) }; Text("NOW PLAYING", color = Dim, fontSize = 10.sp, letterSpacing = 2.sp); IconButton(onClick = queue) { Icon(Icons.Rounded.QueueMusic, "Queue", tint = Txt) } }
            Spacer(Modifier.weight(1f))
            Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF444B57), Color(0xFF171A20), Color(0xFF282E38)))), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.GraphicEq, null, tint = Accent, modifier = Modifier.size(90.dp)); Text("V", color = Color.White.copy(.12f), fontSize = 190.sp, fontWeight = FontWeight.Black) }
            Spacer(Modifier.height(27.dp)); Column(Modifier.fillMaxWidth()) { Text(title, color = Txt, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(artist, color = Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
            Spacer(Modifier.height(20.dp)); Slider(value = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f, onValueChange = seek, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Stroke))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(time(pos), color = Dim, fontSize = 10.sp); Text(time(dur), color = Dim, fontSize = 10.sp) }
            Spacer(Modifier.height(15.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = previous) { Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Txt, modifier = Modifier.size(34.dp)) }; Surface(onClick = toggle, shape = CircleShape, color = Accent, modifier = Modifier.size(66.dp)) { Box(contentAlignment = Alignment.Center) { Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play pause", tint = Bg, modifier = Modifier.size(34.dp)) } }; IconButton(onClick = next) { Icon(Icons.Rounded.SkipNext, "Next", tint = Txt, modifier = Modifier.size(34.dp)) } }
            Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 25.dp), horizontalArrangement = Arrangement.SpaceEvenly) { TextButton(onClick = sleep) { Icon(Icons.Rounded.Timer, null, tint = Sub); Text("Sleep", color = Sub) }; TextButton(onClick = queue) { Icon(Icons.Rounded.QueueMusic, null, tint = Sub); Text("Queue", color = Sub) }; TextButton(onClick = lyrics) { Icon(Icons.Rounded.Subtitles, null, tint = Sub); Text("Lyrics", color = Sub) } }
            Spacer(Modifier.weight(.25f))
        }
    }
}

@Composable private fun MiniPlayer(title: String, artist: String, playing: Boolean, pos: Long, dur: Long, open: () -> Unit, toggle: () -> Unit, next: () -> Unit) {
    Surface(color = Color(0xFF1A1E25).copy(.97f), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Color.White.copy(.13f)), modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).clickable(onClick = open)) {
        Column { Row(Modifier.padding(start = 11.dp, end = 4.dp, top = 7.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(39.dp).clip(RoundedCornerShape(11.dp)).background(Surface2), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.GraphicEq, null, tint = Accent) }; Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(title, color = Txt, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(artist, color = Sub, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }; IconButton(onClick = next) { Icon(Icons.Rounded.SkipNext, "Next", tint = Sub) }; IconButton(onClick = toggle) { Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play pause", tint = Txt) } }; LinearProgressIndicator(progress = { if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth().height(2.dp), color = Accent, trackColor = Color.Transparent) }
    }
}

@Composable private fun FloatingNav(selected: Tab, onSelect: (Tab) -> Unit) {
    Surface(color = Color(0xFF191D24).copy(.97f), shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, Color.White.copy(.12f)), modifier = Modifier.fillMaxWidth().padding(start = 13.dp, end = 13.dp, top = 3.dp, bottom = 7.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            Tab.values().forEach { item -> val active = item == selected; Column(Modifier.clip(RoundedCornerShape(15.dp)).clickable { onSelect(item) }.background(if (active) Color.White.copy(.10f) else Color.Transparent).padding(horizontal = 10.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) { Icon(item.icon, item.label, tint = if (active) Txt else Dim, modifier = Modifier.size(19.dp)); Text(item.label, color = if (active) Txt else Dim, fontSize = 9.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal) } }
        }
    }
}

@Composable private fun SleepDialog(active: Int, dismiss: () -> Unit, set: (Int) -> Unit) {
    AlertDialog(onDismissRequest = dismiss, title = { Text("Sleep timer", color = Txt) }, text = { Column { Text("Pause local playback after", color = Sub, fontSize = 12.sp); listOf(0, 5, 10, 15, 30, 45, 60, 90).forEach { m -> Row(Modifier.fillMaxWidth().clickable { set(m) }.padding(5.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(active == m, { set(m) }, colors = RadioButtonDefaults.colors(selectedColor = Accent)); Text(if (m == 0) "Off" else "$m minutes", color = Txt) } } } }, confirmButton = { TextButton(onClick = dismiss) { Text("Close", color = Accent) } }, containerColor = Surface1)
}

@Composable private fun QueueDialog(controller: MediaController?, dismiss: () -> Unit) {
    val titles = remember(controller?.mediaItemCount) { (0 until (controller?.mediaItemCount ?: 0)).map { i -> controller?.getMediaItemAt(i)?.mediaMetadata?.title?.toString() ?: "Track ${i + 1}" } }
    AlertDialog(onDismissRequest = dismiss, title = { Text("Up next", color = Txt) }, text = { if (titles.isEmpty()) Text("Your queue is empty.", color = Sub) else Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState())) { titles.forEachIndexed { i, s -> Text("${i + 1}.  $s", color = if (i == controller?.currentMediaItemIndex) Txt else Sub, modifier = Modifier.padding(vertical = 7.dp), fontSize = 12.sp) } } }, confirmButton = { TextButton(onClick = dismiss) { Text("Done", color = Accent) } }, containerColor = Surface1)
}

@Composable private fun GlassCard(content: @Composable ColumnScope.() -> Unit) { Surface(color = Surface1, shape = RoundedCornerShape(25.dp), border = BorderStroke(1.dp, Stroke)) { Column(content = content) } }
@Composable private fun Heading(label: String, trailing: String) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = Dim, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold); Text(trailing, color = Dim, fontSize = 10.sp) } }
@Composable private fun EmptyCard(title: String, sub: String, icon: ImageVector) { Surface(color = Surface1, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Stroke), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Column(Modifier.fillMaxWidth().padding(21.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Sub, modifier = Modifier.size(27.dp)); Text(title, color = Txt, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 9.dp)); Text(sub, color = Sub, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp)) } } }
@Composable private fun TrackRow(t: Track, number: Int?, click: () -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = click).padding(vertical = 8.dp, horizontal = 3.dp), verticalAlignment = Alignment.CenterVertically) { if (number != null) Text(number.toString().padStart(2, '0'), color = Dim, fontSize = 10.sp, modifier = Modifier.width(27.dp)); Box(Modifier.size(41.dp).clip(RoundedCornerShape(11.dp)).background(Surface2), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MusicNote, null, tint = Accent) }; Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(t.title, color = Txt, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("${t.artist}  •  ${t.album}", color = Sub, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp)) }; Text(time(t.duration), color = Dim, fontSize = 9.sp); Icon(Icons.Rounded.PlayArrow, null, tint = Sub, modifier = Modifier.padding(start = 6.dp).size(18.dp)) } }
@Composable private fun FeatureCard(title: String, sub: String, icon: ImageVector, modifier: Modifier) { Surface(color = Surface1, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Stroke), modifier = modifier.height(105.dp)) { Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) { Icon(icon, null, tint = Accent); Column { Text(title, color = Txt, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text(sub, color = Dim, fontSize = 9.sp) } } } }
@Composable private fun SettingRow(title: String, sub: String, icon: ImageVector, click: () -> Unit) { Surface(color = Surface1, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Stroke), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable(onClick = click)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Accent); Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(title, color = Txt, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text(sub, color = Sub, fontSize = 10.sp) }; Icon(Icons.Rounded.ChevronRight, null, tint = Dim) } } }
private fun time(ms: Long): String { val s = (ms.coerceAtLeast(0L) / 1000); return String.format(Locale.getDefault(), "%d:%02d", s / 60, s % 60) }
