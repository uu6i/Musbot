# VAMPS MUSIC 1.0 — Android source

Native Kotlin + Jetpack Compose Android music app with an Obsidian / Liquid Glass visual direction.

## Implemented in this build

- Five-screen app structure: Home, Search, Library, Connect and Profile.
- Responsive Compose layouts with a floating glass-style navigation bar and persistent mini-player.
- Android MediaStore audio-library scan using the Android audio permission model.
- Local playback through AndroidX Media3 ExoPlayer and a MediaSessionService for background playback and system media controls.
- Current-track metadata, seek, previous/next, queue display and sleep timer.
- Local library search and in-memory liked-track state.
- Provider cards that launch installed Spotify, YouTube, YouTube Music and SoundCloud apps; they explicitly do not claim account authorization.
- Custom VAMPS vector launcher mark.

## Not yet implemented / requires provider setup

Spotify OAuth and App Remote, SoundCloud OAuth/API, Google/YouTube developer authorization, licensed lyrics, cloud recommendations, playlist persistence, full equalizer controls, crossfade, provider downloads and casting integrations are not active in this build. Provider integrations require developer registrations, client IDs, redirect URIs, approved scopes and policy-compliant playback paths. YouTube Music has no public unrestricted third-party streaming API. The Connect screen labels these limitations rather than simulating a connected account.

Crossfade, gapless playback and equalizer support require additional work and depend on source/decoder/device capabilities. The sleep timer currently stops VAMPS-managed playback.

## Build

- JDK 17
- Android SDK 36
- Gradle 8.13
- Android Gradle Plugin 8.11.1
- Kotlin 2.2.20

Run:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

The repository includes `.github/workflows/android-apk.yml`. Push to `main` or manually run **Build VAMPS MUSIC APK** in GitHub Actions. The APK is uploaded as the `VAMPS-MUSIC-debug` artifact.
